package model;

/**
 * Modelo da tabela funcoes.
 */
public class funcoes {

    private int idFuncao;
    private String dsFuncao;

    public int getIdFuncao() {
        return idFuncao;
    }

    public void setIdFuncao(int idFuncao) {
        this.idFuncao = idFuncao;
    }

    public String getDsFuncao() {
        return dsFuncao;
    }

    public void setDsFuncao(String dsFuncao) {
        this.dsFuncao = dsFuncao;
    }
}
