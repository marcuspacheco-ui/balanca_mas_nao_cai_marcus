package model;

/**
 * Modelo da tabela fases.
 */
public class fases {

    private int idFase;
    private String dsFase;

    public int getIdFase() {
        return idFase;
    }

    public void setIdFase(int idFase) {
        this.idFase = idFase;
    }

    public String getDsFase() {
        return dsFase;
    }

    public void setDsFase(String dsFase) {
        this.dsFase = dsFase;
    }
}
