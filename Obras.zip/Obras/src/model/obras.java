package model;

import java.util.Date;

/**
 * Modelo da tabela obras.
 */
public class obras {

    private int idObra;
    private String dsObra;
    private Date dtInicio;
    private Date dtFim;
    private int idEngenheiro;
    private String nmEngenheiro;
    private String nrCREA;
    private Date dtAdmissao;

    public int getIdObra() {
        return idObra;
    }

    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    public String getDsObra() {
        return dsObra;
    }

    public void setDsObra(String dsObra) {
        this.dsObra = dsObra;
    }

    public Date getDtInicio() {
        return dtInicio;
    }

    public void setDtInicio(Date dtInicio) {
        this.dtInicio = dtInicio;
    }

    public Date getDtFim() {
        return dtFim;
    }

    public void setDtFim(Date dtFim) {
        this.dtFim = dtFim;
    }

    public int getIdEngenheiro() {
        return idEngenheiro;
    }

    public void setIdEngenheiro(int idEngenheiro) {
        this.idEngenheiro = idEngenheiro;
    }

    public String getNmEngenheiro() {
        return nmEngenheiro;
    }

    public void setNmEngenheiro(String nmEngenheiro) {
        this.nmEngenheiro = nmEngenheiro;
    }

    public String getNrCREA() {
        return nrCREA;
    }

    public void setNrCREA(String nrCREA) {
        this.nrCREA = nrCREA;
    }

    public Date getDtAdmissao() {
        return dtAdmissao;
    }

    public void setDtAdmissao(Date dtAdmissao) {
        this.dtAdmissao = dtAdmissao;
    }
}
