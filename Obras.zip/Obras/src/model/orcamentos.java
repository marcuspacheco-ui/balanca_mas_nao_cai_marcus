package model;

import java.util.Date;

/**
 * Modelo da tabela orcamentos.
 */
public class orcamentos {

    private int idOrcamento;
    private Date dtOrcamento;
    private Date dtAprovacao;

    public int getIdOrcamento() {
        return idOrcamento;
    }

    public void setIdOrcamento(int idOrcamento) {
        this.idOrcamento = idOrcamento;
    }

    public Date getDtOrcamento() {
        return dtOrcamento;
    }

    public void setDtOrcamento(Date dtOrcamento) {
        this.dtOrcamento = dtOrcamento;
    }

    public Date getDtAprovacao() {
        return dtAprovacao;
    }

    public void setDtAprovacao(Date dtAprovacao) {
        this.dtAprovacao = dtAprovacao;
    }
}
