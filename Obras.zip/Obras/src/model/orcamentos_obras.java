package model;

import java.util.Date;

/**
 * Modelo da tabela orcamentos_obras.
 */
public class orcamentos_obras {

    private int idOrcamento;
    private int idObra;
    private Date dtInicio;
    private Date dtFim;
    private java.math.BigDecimal vlPrevisto;
    private java.math.BigDecimal vlRealizado;

    public int getIdOrcamento() {
        return idOrcamento;
    }

    public void setIdOrcamento(int idOrcamento) {
        this.idOrcamento = idOrcamento;
    }

    public int getIdObra() {
        return idObra;
    }

    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    public Date getDtInicio() {
        return dtInicio;
    }

    public void setDtInicio(Date dtInicio) {
        this.dtInicio = dtInicio;
    }

    public Date getDtFim() {
        return dtFim;
    }

    public void setDtFim(Date dtFim) {
        this.dtFim = dtFim;
    }

    public java.math.BigDecimal getVlPrevisto() {
        return vlPrevisto;
    }

    public void setVlPrevisto(java.math.BigDecimal vlPrevisto) {
        this.vlPrevisto = vlPrevisto;
    }

    public java.math.BigDecimal getVlRealizado() {
        return vlRealizado;
    }

    public void setVlRealizado(java.math.BigDecimal vlRealizado) {
        this.vlRealizado = vlRealizado;
    }
}
