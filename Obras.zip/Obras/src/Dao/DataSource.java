package Dao;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 * Conexão com o MySQL.
 * A conexão é aberta uma única vez e reaproveitada por todas as telas.
 */
public class DataSource {

    private static Connection conexao;          // compartilhada por todo o sistema
    private static long ultimoUso = 0;          // para não testar a conexão a cada clique
    private static final Object TRAVA = new Object();

    private String hostname;
    private int porta;
    private String database;
    private String username;
    private String password;

    public DataSource() {
        synchronized (TRAVA) {
            try {
                if (conexao != null && !conexao.isClosed()) {
                    // só confirma se a conexão ainda vale quando ficou mais de 1 minuto parada
                    if (System.currentTimeMillis() - ultimoUso < 60000 || conexao.isValid(2)) {
                        ultimoUso = System.currentTimeMillis();
                        return;
                    }
                }
            } catch (SQLException ex) {
                conexao = null;
            }
            try {
                hostname = "192.168.20.5";
                porta = 3306;
                database = "balanca_mas_nao_cai";
                username = "root";
                password = "12345";

                String url = "jdbc:mysql://" + hostname + ":" + porta + "/" + database
                        + "?useTimezone=true&serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true&connectTimeout=5000&socketTimeout=30000";
                long inicio = System.currentTimeMillis();
                DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
                conexao = DriverManager.getConnection(url, username, password);
                ultimoUso = System.currentTimeMillis();
                System.out.println("[Banco] conectado em " + (ultimoUso - inicio) + " ms");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "ERRO na conexão: " + ex.getMessage());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "ERRO geral: " + ex.getMessage());
            }
        }
    }

    public Connection getConnection() {
        return conexao;
    }

    /** Mantida para os DAOs: a conexão fica aberta de propósito e só fecha junto com o programa. */
    public void closeDataSource() {
    }

    /** Fecha de verdade a conexão (use só ao encerrar o sistema). */
    public static void fecharConexao() {
        synchronized (TRAVA) {
            try {
                if (conexao != null && !conexao.isClosed()) {
                    conexao.close();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "ERRO ao desconectar: " + ex.getMessage());
            } finally {
                conexao = null;
            }
        }
    }
}
