package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.usuarios;

/**
 * Acesso a dados da tabela usuarios (insert, update, select e delete).
 */
public class daoUsuarios {

    private DataSource dataSource;

    public daoUsuarios(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** Valida o login (e-mail ou nome + senha). Retorna o usuário ou null se e-mail/senha não conferem. */
    public usuarios autentica(String email, String senha) {
        usuarios u = null;
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idUsuario, Nome, Email FROM usuarios WHERE (Email = ? OR Nome = ?) AND Senha = ?");
            ps.setString(1, email);
            ps.setString(2, email);
            ps.setString(3, senha);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                u = new usuarios();
                u.setIdUsuario(rs.getInt("idUsuario"));
                u.setNome(rs.getString("Nome"));
                u.setEmail(rs.getString("Email"));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao validar login!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return u;
    }

    public ArrayList<usuarios> consulta() {
        ArrayList<usuarios> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idUsuario, Nome, Email FROM usuarios ORDER BY idUsuario");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                usuarios x = new usuarios();
                x.setIdUsuario(rs.getInt("idUsuario"));
                x.setNome(rs.getString("Nome"));
                x.setEmail(rs.getString("Email"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public ArrayList<usuarios> seleciona(String nome) {
        ArrayList<usuarios> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idUsuario, Nome, Email FROM usuarios WHERE Nome LIKE ? ORDER BY idUsuario");
            ps.setString(1, "%" + nome + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                usuarios x = new usuarios();
                x.setIdUsuario(rs.getInt("idUsuario"));
                x.setNome(rs.getString("Nome"));
                x.setEmail(rs.getString("Email"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao selecionar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public int proximoId() {
        int id = 1;
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT COALESCE(MAX(idUsuario), 0) + 1 FROM usuarios");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar código!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return id;
    }

    public void incluir(usuarios x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO usuarios (idUsuario, Nome, Email, Senha) VALUES (?, ?, ?, ?)");
            ps.setInt(1, x.getIdUsuario());
            ps.setString(2, x.getNome());
            ps.setString(3, x.getEmail());
            ps.setString(4, x.getSenha());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    /** Altera nome e e-mail; a senha só muda se vier preenchida. */
    public void alterar(usuarios x) {
        try {
            boolean trocaSenha = x.getSenha() != null && !x.getSenha().isEmpty();
            String sql = "UPDATE usuarios SET Nome = ?, Email = ?" + (trocaSenha ? ", Senha = ?" : "") + " WHERE idUsuario = ?";
            PreparedStatement ps = dataSource.getConnection().prepareStatement(sql);
            ps.setString(1, x.getNome());
            ps.setString(2, x.getEmail());
            int i = 3;
            if (trocaSenha) {
                ps.setString(i++, x.getSenha());
            }
            ps.setInt(i, x.getIdUsuario());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int codigo) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM usuarios WHERE idUsuario = ?");
            ps.setInt(1, codigo);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
