package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.funcoes;

/**
 * Acesso a dados da tabela funcoes (insert, update, select e delete).
 */
public class daoFuncoes {

    private DataSource dataSource;

    public daoFuncoes(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** Lista todos os registros. */
    public ArrayList<funcoes> consulta() {
        ArrayList<funcoes> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idFuncao, dsFuncao FROM funcoes ORDER BY idFuncao");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                funcoes x = new funcoes();
                x.setIdFuncao(rs.getInt("idFuncao"));
                x.setDsFuncao(rs.getString("dsFuncao"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    /** Busca pelo texto da descrição (LIKE). */
    public ArrayList<funcoes> seleciona(String texto) {
        ArrayList<funcoes> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idFuncao, dsFuncao FROM funcoes WHERE dsFuncao LIKE ? ORDER BY idFuncao");
            ps.setString(1, "%" + texto + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                funcoes x = new funcoes();
                x.setIdFuncao(rs.getInt("idFuncao"));
                x.setDsFuncao(rs.getString("dsFuncao"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao selecionar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    /** Próximo código livre (MAX + 1). */
    public int proximoId() {
        int id = 1;
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT COALESCE(MAX(idFuncao), 0) + 1 FROM funcoes");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar código!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return id;
    }

    public void incluir(funcoes x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO funcoes (idFuncao, dsFuncao) VALUES (?, ?)");
            ps.setInt(1, x.getIdFuncao());
            ps.setString(2, x.getDsFuncao());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(funcoes x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE funcoes SET dsFuncao = ? WHERE idFuncao = ?");
            ps.setString(1, x.getDsFuncao());
            ps.setInt(2, x.getIdFuncao());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int codigo) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM funcoes WHERE idFuncao = ?");
            ps.setInt(1, codigo);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
