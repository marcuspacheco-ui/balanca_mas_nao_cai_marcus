package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.math.BigDecimal;
import model.orcamentos_obras;

/**
 * Acesso a dados da tabela orcamentos_obras (insert, update, select e delete).
 */
public class daoOrcamentosObras {

    private DataSource dataSource;

    public daoOrcamentosObras(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<orcamentos_obras> consulta() {
        ArrayList<orcamentos_obras> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado FROM orcamentos_obras ORDER BY idOrcamento, idObra");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                orcamentos_obras x = new orcamentos_obras();
                x.setIdOrcamento(rs.getInt("idOrcamento"));
                x.setIdObra(rs.getInt("idObra"));
                x.setDtInicio(rs.getDate("dtInicio"));
                x.setDtFim(rs.getDate("dtFim"));
                x.setVlPrevisto(rs.getBigDecimal("vlPrevisto"));
                x.setVlRealizado(rs.getBigDecimal("vlRealizado"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public void incluir(orcamentos_obras x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO orcamentos_obras (idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setInt(1, x.getIdOrcamento());
            ps.setInt(2, x.getIdObra());
            ps.setDate(3, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(4, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.setBigDecimal(5, x.getVlPrevisto());
            ps.setBigDecimal(6, x.getVlRealizado());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(orcamentos_obras x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE orcamentos_obras SET dtInicio = ?, dtFim = ?, vlPrevisto = ?, vlRealizado = ? WHERE idOrcamento = ? AND idObra = ?");
            ps.setDate(1, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(2, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.setBigDecimal(3, x.getVlPrevisto());
            ps.setBigDecimal(4, x.getVlRealizado());
            ps.setInt(5, x.getIdOrcamento());
            ps.setInt(6, x.getIdObra());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idOrcamento, int idObra) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM orcamentos_obras WHERE idOrcamento = ? AND idObra = ?");
            ps.setInt(1, idOrcamento);
            ps.setInt(2, idObra);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
