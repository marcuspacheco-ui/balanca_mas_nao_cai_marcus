package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.fases;

/**
 * Acesso a dados da tabela fases (insert, update, select e delete).
 */
public class daoFases {

    private DataSource dataSource;

    public daoFases(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** Lista todos os registros. */
    public ArrayList<fases> consulta() {
        ArrayList<fases> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idFase, dsFase FROM fases ORDER BY idFase");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                fases x = new fases();
                x.setIdFase(rs.getInt("idFase"));
                x.setDsFase(rs.getString("dsFase"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    /** Busca pelo texto da descrição (LIKE). */
    public ArrayList<fases> seleciona(String texto) {
        ArrayList<fases> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idFase, dsFase FROM fases WHERE dsFase LIKE ? ORDER BY idFase");
            ps.setString(1, "%" + texto + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                fases x = new fases();
                x.setIdFase(rs.getInt("idFase"));
                x.setDsFase(rs.getString("dsFase"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao selecionar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    /** Próximo código livre (MAX + 1). */
    public int proximoId() {
        int id = 1;
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT COALESCE(MAX(idFase), 0) + 1 FROM fases");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar código!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return id;
    }

    public void incluir(fases x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO fases (idFase, dsFase) VALUES (?, ?)");
            ps.setInt(1, x.getIdFase());
            ps.setString(2, x.getDsFase());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(fases x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE fases SET dsFase = ? WHERE idFase = ?");
            ps.setString(1, x.getDsFase());
            ps.setInt(2, x.getIdFase());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int codigo) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM fases WHERE idFase = ?");
            ps.setInt(1, codigo);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
