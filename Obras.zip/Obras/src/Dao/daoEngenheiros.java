package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.engenheiros;

/**
 * Acesso a dados da tabela engenheiros (insert, update, select e delete).
 */
public class daoEngenheiros {

    private DataSource dataSource;

    public daoEngenheiros(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** Lista todos os registros. */
    public ArrayList<engenheiros> consulta() {
        ArrayList<engenheiros> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idEngenheiro, dsNome, nrCREA, dtAdmissao FROM engenheiros ORDER BY idEngenheiro");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                engenheiros x = new engenheiros();
                x.setIdEngenheiro(rs.getInt("idEngenheiro"));
                x.setDsNome(rs.getString("dsNome"));
                x.setNrCREA(rs.getString("nrCREA"));
                x.setDtAdmissao(rs.getDate("dtAdmissao"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    /** Busca pelo texto da descrição (LIKE). */
    public ArrayList<engenheiros> seleciona(String texto) {
        ArrayList<engenheiros> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idEngenheiro, dsNome, nrCREA, dtAdmissao FROM engenheiros WHERE dsNome LIKE ? ORDER BY idEngenheiro");
            ps.setString(1, "%" + texto + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                engenheiros x = new engenheiros();
                x.setIdEngenheiro(rs.getInt("idEngenheiro"));
                x.setDsNome(rs.getString("dsNome"));
                x.setNrCREA(rs.getString("nrCREA"));
                x.setDtAdmissao(rs.getDate("dtAdmissao"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao selecionar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    /** Próximo código livre (MAX + 1). */
    public int proximoId() {
        int id = 1;
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT COALESCE(MAX(idEngenheiro), 0) + 1 FROM engenheiros");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar código!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return id;
    }

    public void incluir(engenheiros x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO engenheiros (idEngenheiro, dsNome, nrCREA, dtAdmissao) VALUES (?, ?, ?, ?)");
            ps.setInt(1, x.getIdEngenheiro());
            ps.setString(2, x.getDsNome());
            ps.setString(3, x.getNrCREA());
            ps.setDate(4, x.getDtAdmissao() == null ? null : new java.sql.Date(x.getDtAdmissao().getTime()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(engenheiros x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE engenheiros SET dsNome = ?, nrCREA = ?, dtAdmissao = ? WHERE idEngenheiro = ?");
            ps.setString(1, x.getDsNome());
            ps.setString(2, x.getNrCREA());
            ps.setDate(3, x.getDtAdmissao() == null ? null : new java.sql.Date(x.getDtAdmissao().getTime()));
            ps.setInt(4, x.getIdEngenheiro());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int codigo) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM engenheiros WHERE idEngenheiro = ?");
            ps.setInt(1, codigo);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
