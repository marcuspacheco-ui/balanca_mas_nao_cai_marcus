package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.orcamentos;

/**
 * Acesso a dados da tabela orcamentos (insert, update, select e delete).
 */
public class daoOrcamentos {

    private DataSource dataSource;

    public daoOrcamentos(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<orcamentos> consulta() {
        ArrayList<orcamentos> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idOrcamento, dtOrcamento, dtAprovacao FROM orcamentos ORDER BY idOrcamento");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                orcamentos x = new orcamentos();
                x.setIdOrcamento(rs.getInt("idOrcamento"));
                x.setDtOrcamento(rs.getDate("dtOrcamento"));
                x.setDtAprovacao(rs.getDate("dtAprovacao"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public void incluir(orcamentos x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO orcamentos (idOrcamento, dtOrcamento, dtAprovacao) VALUES (?, ?, ?)");
            ps.setInt(1, x.getIdOrcamento());
            ps.setDate(2, x.getDtOrcamento() == null ? null : new java.sql.Date(x.getDtOrcamento().getTime()));
            ps.setDate(3, x.getDtAprovacao() == null ? null : new java.sql.Date(x.getDtAprovacao().getTime()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(orcamentos x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE orcamentos SET dtOrcamento = ?, dtAprovacao = ? WHERE idOrcamento = ?");
            ps.setDate(1, x.getDtOrcamento() == null ? null : new java.sql.Date(x.getDtOrcamento().getTime()));
            ps.setDate(2, x.getDtAprovacao() == null ? null : new java.sql.Date(x.getDtAprovacao().getTime()));
            ps.setInt(3, x.getIdOrcamento());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idOrcamento) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM orcamentos WHERE idOrcamento = ?");
            ps.setInt(1, idOrcamento);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
