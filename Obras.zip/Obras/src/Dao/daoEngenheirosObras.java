package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.engenheiros_obras;

/**
 * Acesso a dados da tabela engenheiros_obras (insert, update, select e delete).
 */
public class daoEngenheirosObras {

    private DataSource dataSource;

    public daoEngenheirosObras(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<engenheiros_obras> consulta() {
        ArrayList<engenheiros_obras> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idEngenheiro, idObra, dtInicio, dtFim, idFuncao FROM engenheiros_obras ORDER BY idEngenheiro, idObra");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                engenheiros_obras x = new engenheiros_obras();
                x.setIdEngenheiro(rs.getInt("idEngenheiro"));
                x.setIdObra(rs.getInt("idObra"));
                x.setDtInicio(rs.getDate("dtInicio"));
                x.setDtFim(rs.getDate("dtFim"));
                x.setIdFuncao(rs.getInt("idFuncao"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public void incluir(engenheiros_obras x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO engenheiros_obras (idEngenheiro, idObra, dtInicio, dtFim, idFuncao) VALUES (?, ?, ?, ?, ?)");
            ps.setInt(1, x.getIdEngenheiro());
            ps.setInt(2, x.getIdObra());
            ps.setDate(3, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(4, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.setInt(5, x.getIdFuncao());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(engenheiros_obras x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE engenheiros_obras SET dtInicio = ?, dtFim = ?, idFuncao = ? WHERE idEngenheiro = ? AND idObra = ?");
            ps.setDate(1, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(2, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.setInt(3, x.getIdFuncao());
            ps.setInt(4, x.getIdEngenheiro());
            ps.setInt(5, x.getIdObra());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idEngenheiro, int idObra) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM engenheiros_obras WHERE idEngenheiro = ? AND idObra = ?");
            ps.setInt(1, idEngenheiro);
            ps.setInt(2, idObra);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
