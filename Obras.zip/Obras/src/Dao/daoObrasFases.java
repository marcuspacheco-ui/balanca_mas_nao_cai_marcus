package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.obras_fases;

/**
 * Acesso a dados da tabela obras_fases (insert, update, select e delete).
 */
public class daoObrasFases {

    private DataSource dataSource;

    public daoObrasFases(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<obras_fases> consulta() {
        ArrayList<obras_fases> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT idObra, idFase, dtInicio, dtFim FROM obras_fases ORDER BY idObra, idFase");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                obras_fases x = new obras_fases();
                x.setIdObra(rs.getInt("idObra"));
                x.setIdFase(rs.getInt("idFase"));
                x.setDtInicio(rs.getDate("dtInicio"));
                x.setDtFim(rs.getDate("dtFim"));
                lista.add(x);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public void incluir(obras_fases x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO obras_fases (idObra, idFase, dtInicio, dtFim) VALUES (?, ?, ?, ?)");
            ps.setInt(1, x.getIdObra());
            ps.setInt(2, x.getIdFase());
            ps.setDate(3, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(4, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(obras_fases x) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE obras_fases SET dtInicio = ?, dtFim = ? WHERE idObra = ? AND idFase = ?");
            ps.setDate(1, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(2, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.setInt(3, x.getIdObra());
            ps.setInt(4, x.getIdFase());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idObra, int idFase) {
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM obras_fases WHERE idObra = ? AND idFase = ?");
            ps.setInt(1, idObra);
            ps.setInt(2, idFase);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
