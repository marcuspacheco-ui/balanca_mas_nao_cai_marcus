package Dao;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.obras;

/**
 * Acesso a dados da tabela obras (insert, update, select e delete).
 * As consultas trazem também nome, CREA e admissão do engenheiro responsável.
 */
public class daoObras {

    private DataSource dataSource;

    public daoObras(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // Nomes reais das colunas da tabela obras, descobertos no banco na primeira vez
    private static String cId, cDesc, cIni, cFim, cEng;

    /** Lê os nomes das colunas da tabela obras (funciona mesmo que sejam diferentes do diagrama). */
    private void colunas() throws SQLException {
        if (cId != null) {
            return;
        }
        ResultSetMetaData md = dataSource.getConnection().prepareStatement("SELECT * FROM obras WHERE 1 = 0").executeQuery().getMetaData();
        String id = null, desc = null, ini = null, fim = null, eng = null, primeiroTexto = null;
        for (int i = 1; i <= md.getColumnCount(); i++) {
            String n = md.getColumnName(i);
            String l = n.toLowerCase();
            int tipo = md.getColumnType(i);
            boolean texto = tipo == Types.VARCHAR || tipo == Types.CHAR || tipo == Types.LONGVARCHAR;
            boolean data = tipo == Types.DATE || tipo == Types.TIMESTAMP;
            boolean numero = tipo == Types.INTEGER || tipo == Types.SMALLINT || tipo == Types.BIGINT
                    || tipo == Types.TINYINT || tipo == Types.NUMERIC || tipo == Types.DECIMAL;
            if (i == 1) {
                id = n;
            } else if (numero && l.contains("engenheiro") && (eng == null || l.startsWith("id"))) {
                eng = n;                                     // ex.: idEngenheiro
            } else if (data && (l.contains("inicio") || l.contains("início")) && ini == null) {
                ini = n;                                     // ex.: dtInicio
            } else if (data && (l.contains("fim") || l.contains("termino") || l.contains("final")) && fim == null) {
                fim = n;                                     // ex.: dtFim
            } else if (texto && desc == null && (l.contains("desc") || l.startsWith("ds") || l.contains("obra"))) {
                desc = n;                                    // ex.: dsObra / Descricao
            }
            if (texto && primeiroTexto == null && !l.contains("crea")) {
                primeiroTexto = n;
            }
        }
        if (desc == null) {
            desc = primeiroTexto;
        }
        cId = id; cDesc = desc; cIni = ini; cFim = fim; cEng = eng;
        System.out.println("[Banco] colunas de obras: " + cId + ", " + cDesc + ", " + cIni + ", " + cFim + ", " + cEng);
    }

    private String selectBase() throws SQLException {
        colunas();
        return "SELECT o.`" + cId + "` AS idObra, o.`" + cDesc + "` AS dsObra, o.`" + cIni + "` AS dtInicio, o.`" + cFim + "` AS dtFim, "
                + "o.`" + cEng + "` AS idEngenheiro, e.dsNome, e.nrCREA, e.dtAdmissao "
                + "FROM obras o LEFT JOIN engenheiros e ON e.idEngenheiro = o.`" + cEng + "` ";
    }

    private obras monta(ResultSet rs) throws SQLException {
        obras x = new obras();
        x.setIdObra(rs.getInt("idObra"));
        x.setDsObra(rs.getString("dsObra"));
        x.setDtInicio(rs.getDate("dtInicio"));
        x.setDtFim(rs.getDate("dtFim"));
        x.setIdEngenheiro(rs.getInt("idEngenheiro"));
        x.setNmEngenheiro(rs.getString("dsNome"));
        x.setNrCREA(rs.getString("nrCREA"));
        x.setDtAdmissao(rs.getDate("dtAdmissao"));
        return x;
    }

    public ArrayList<obras> consulta() {
        ArrayList<obras> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(selectBase() + "ORDER BY 1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(monta(rs));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public ArrayList<obras> seleciona(String descricao) {
        ArrayList<obras> lista = new ArrayList<>();
        try {
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    selectBase() + "WHERE o.`" + cDesc + "` LIKE ? ORDER BY 1");
            ps.setString(1, "%" + descricao + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(monta(rs));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao selecionar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return lista;
    }

    public int proximoId() {
        int id = 1;
        try {
            colunas();
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "SELECT COALESCE(MAX(`" + cId + "`), 0) + 1 FROM obras");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt(1);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar código!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
        return id;
    }

    public void incluir(obras x) {
        try {
            colunas();
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "INSERT INTO obras (`" + cId + "`, `" + cDesc + "`, `" + cIni + "`, `" + cFim + "`, `" + cEng + "`) VALUES (?, ?, ?, ?, ?)");
            ps.setInt(1, x.getIdObra());
            ps.setString(2, x.getDsObra());
            ps.setDate(3, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(4, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.setInt(5, x.getIdEngenheiro());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(obras x) {
        try {
            colunas();
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "UPDATE obras SET `" + cDesc + "` = ?, `" + cIni + "` = ?, `" + cFim + "` = ?, `" + cEng + "` = ? WHERE `" + cId + "` = ?");
            ps.setString(1, x.getDsObra());
            ps.setDate(2, x.getDtInicio() == null ? null : new java.sql.Date(x.getDtInicio().getTime()));
            ps.setDate(3, x.getDtFim() == null ? null : new java.sql.Date(x.getDtFim().getTime()));
            ps.setInt(4, x.getIdEngenheiro());
            ps.setInt(5, x.getIdObra());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int codigo) {
        try {
            colunas();
            PreparedStatement ps = dataSource.getConnection().prepareStatement(
                    "DELETE FROM obras WHERE `" + cId + "` = ?");
            ps.setInt(1, codigo);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
