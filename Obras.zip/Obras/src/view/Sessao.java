package view;

import model.usuarios;

/**
 * Guarda o usuário logado enquanto o sistema está aberto.
 */
public class Sessao {

    public static usuarios usuario;

    private Sessao() {
    }
}
