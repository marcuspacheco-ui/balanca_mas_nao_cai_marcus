package view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;

/**
 * Funções de apoio das telas: datas e troca de tela.
 */
public class Util {

    private static final String FORMATO = "dd/MM/yyyy";

    private Util() {
    }

    /** Converte "dd/MM/yyyy" em Date. Texto vazio vira null; texto inválido lança ParseException. */
    public static Date parseData(String texto) throws ParseException {
        if (texto == null || texto.trim().isEmpty()) {
            return null;
        }
        SimpleDateFormat f = new SimpleDateFormat(FORMATO);
        f.setLenient(false);
        return f.parse(texto.trim());
    }

    /** Converte Date em "dd/MM/yyyy" (null vira texto vazio). */
    public static String formata(Date data) {
        return data == null ? "" : new SimpleDateFormat(FORMATO).format(data);
    }

    /** A única janela visível do sistema; as telas só trocam o conteúdo dela. */
    private static JFrame janela;

    /**
     * Troca de tela sem abrir janela nova: o conteúdo da tela nova é colocado dentro
     * da janela que já está aberta. Assim a janela continua maximizada (ou do mesmo
     * tamanho) e a troca é instantânea.
     */
    public static void trocar(JFrame atual, JFrame nova) {
        if (janela == null || !janela.isDisplayable()) {
            janela = atual;
        }
        janela.setContentPane(nova.getContentPane());
        janela.setTitle(nova.getTitle());
        janela.getRootPane().setDefaultButton(nova.getRootPane().getDefaultButton());
        if ((janela.getExtendedState() & JFrame.MAXIMIZED_BOTH) != JFrame.MAXIMIZED_BOTH) {
            janela.pack();
            janela.setLocationRelativeTo(null);
        }
        janela.revalidate();
        janela.repaint();
        // a tela "nova" nunca é exibida: ela só serviu para montar o conteúdo
    }

    /** Centraliza o painel principal da tela, para que fique no meio quando a janela for maximizada. */
    public static void centralizar(JFrame tela, javax.swing.JComponent painel) {
        java.awt.Container conteudo = tela.getContentPane();
        conteudo.removeAll();
        conteudo.setBackground(painel.getBackground());
        conteudo.setLayout(new java.awt.GridBagLayout());
        conteudo.add(painel, new java.awt.GridBagConstraints());
        tela.pack();
        tela.setLocationRelativeTo(null);
    }
}
