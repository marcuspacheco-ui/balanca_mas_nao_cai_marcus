package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.funcoes;

public class daoFuncoes {
    private DataSource dataSource;

    public daoFuncoes(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<funcoes> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM funcoes";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<funcoes> lista = new ArrayList<>();
            while (rs.next()) {
                funcoes funcao = new funcoes();
                funcao.setIdFuncao(rs.getInt("idFuncao"));
                funcao.setDsFuncao(rs.getString("dsFuncao"));
                lista.add(funcao);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(funcoes funcao) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO funcoes "
                       + "(dsFuncao) "
                       + "VALUES (?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setString(1, funcao.getDsFuncao());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(funcoes funcao) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE funcoes "
               + "SET dsFuncao=? "
               + "WHERE idFuncao=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setString(1, funcao.getDsFuncao());
            ps.setInt(2, funcao.getIdFuncao());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idFuncao) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM funcoes WHERE (idFuncao=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idFuncao);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
