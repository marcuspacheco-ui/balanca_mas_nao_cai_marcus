package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.fases;

public class daoFases {
    private DataSource dataSource;

    public daoFases(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<fases> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM fases";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<fases> lista = new ArrayList<>();
            while (rs.next()) {
                fases fase = new fases();
                fase.setIdFase(rs.getInt("idFase"));
                fase.setDsFase(rs.getString("dsFase"));
                lista.add(fase);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(fases fase) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO fases "
                       + "(idFase, dsFase) "
                       + "VALUES (?, ?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setInt(1, fase.getIdFase());
            ps.setString(2, fase.getDsFase());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(fases fase) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE fases "
               + "SET dsFase=? "
               + "WHERE idFase=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setString(1, fase.getDsFase());
            ps.setInt(2, fase.getIdFase());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idFase) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM fases WHERE (idFase=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idFase);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
