package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.obras_fases;

public class daoObrasFases {
    private DataSource dataSource;

    public daoObrasFases(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<obras_fases> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM obras_fases";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<obras_fases> lista = new ArrayList<>();
            while (rs.next()) {
                obras_fases obraFase = new obras_fases();
                obraFase.setIdObra(rs.getInt("idObra"));
                obraFase.setIdFase(rs.getInt("idFase"));
                obraFase.setDtInicio(rs.getDate("dtInicio"));
                obraFase.setDtFim(rs.getDate("dtFim"));
                lista.add(obraFase);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(obras_fases obraFase) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO obras_fases "
                       + "(idObra, idFase, dtInicio, dtFim) "
                       + "VALUES (?, ?, ?, ?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setInt(1, obraFase.getIdObra());
            ps.setInt(2, obraFase.getIdFase());
            ps.setDate(3, obraFase.getDtInicio() == null ? null : new java.sql.Date(obraFase.getDtInicio().getTime()));
            ps.setDate(4, obraFase.getDtFim() == null ? null : new java.sql.Date(obraFase.getDtFim().getTime()));

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(obras_fases obraFase) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE obras_fases "
               + "SET dtInicio=?, dtFim=? "
               + "WHERE idObra=? AND idFase=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setDate(1, obraFase.getDtInicio() == null ? null : new java.sql.Date(obraFase.getDtInicio().getTime()));
            ps.setDate(2, obraFase.getDtFim() == null ? null : new java.sql.Date(obraFase.getDtFim().getTime()));
            ps.setInt(3, obraFase.getIdObra());
            ps.setInt(4, obraFase.getIdFase());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idObra, int idFase) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM obras_fases WHERE (idObra=? AND idFase=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idObra);
            ps.setInt(2, idFase);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
