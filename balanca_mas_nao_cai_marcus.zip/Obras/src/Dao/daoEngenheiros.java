package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.engenheiros;

public class daoEngenheiros {
    private DataSource dataSource;

    public daoEngenheiros(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<engenheiros> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM engenheiros";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<engenheiros> lista = new ArrayList<>();
            while (rs.next()) {
                engenheiros eng = new engenheiros();
                eng.setIdEngenheiro(rs.getInt("idEngenheiro"));
                eng.setDsNome(rs.getString("dsNome"));
                eng.setNrCREA(rs.getString("nrCREA"));
                eng.setDtAdmissao(rs.getDate("dtAdmissao"));
                lista.add(eng);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(engenheiros eng) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO engenheiros "
                       + "(dsNome, nrCREA, dtAdmissao) "
                       + "VALUES (?, ?, ?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setString(1, eng.getDsNome());
            ps.setString(2, eng.getNrCREA());
            ps.setDate(3, eng.getDtAdmissao() == null ? null : new java.sql.Date(eng.getDtAdmissao().getTime()));

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(engenheiros eng) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE engenheiros "
               + "SET dsNome=?, nrCREA=?, dtAdmissao=? "
               + "WHERE idEngenheiro=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setString(1, eng.getDsNome());
            ps.setString(2, eng.getNrCREA());
            ps.setDate(3, eng.getDtAdmissao() == null ? null : new java.sql.Date(eng.getDtAdmissao().getTime()));
            ps.setInt(4, eng.getIdEngenheiro());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idEngenheiro) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM engenheiros WHERE (idEngenheiro=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idEngenheiro);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
