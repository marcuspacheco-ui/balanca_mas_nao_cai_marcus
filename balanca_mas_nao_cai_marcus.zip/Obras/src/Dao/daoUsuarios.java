package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.usuarios;

public class daoUsuarios {
    private DataSource dataSource;

    public daoUsuarios(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<usuarios> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM usuarios";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<usuarios> lista = new ArrayList<>();
            while (rs.next()) {
                usuarios usu = new usuarios();
                usu.setIdUsuario(rs.getInt("idUsuario"));
                usu.setNome(rs.getString("Nome"));
                usu.setEmail(rs.getString("Email"));
                lista.add(usu);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public usuarios login(String usuario, String senha) {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM usuarios WHERE (Email=? OR Nome=?) AND Senha=?";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setString(1, usuario);
            ps.setString(2, usuario);
            ps.setString(3, senha);
            ResultSet rs = ps.executeQuery();

            usuarios usu = null;
            if (rs.next()) {
                usu = new usuarios();
                usu.setIdUsuario(rs.getInt("idUsuario"));
                usu.setNome(rs.getString("Nome"));
                usu.setEmail(rs.getString("Email"));
            }
            ps.close();
            return usu;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao entrar: " + ex.getMessage());
            return null;
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void incluir(usuarios usu) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO usuarios "
                       + "(Nome, Email, Senha) "
                       + "VALUES (?, ?, ?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setString(1, usu.getNome());
            ps.setString(2, usu.getEmail());
            ps.setString(3, usu.getSenha());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(usuarios usu) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE usuarios "
               + "SET Nome=?, Email=?, Senha=? "
               + "WHERE idUsuario=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setString(1, usu.getNome());
            ps.setString(2, usu.getEmail());
            ps.setString(3, usu.getSenha());
            ps.setInt(4, usu.getIdUsuario());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idUsuario) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM usuarios WHERE (idUsuario=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idUsuario);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
