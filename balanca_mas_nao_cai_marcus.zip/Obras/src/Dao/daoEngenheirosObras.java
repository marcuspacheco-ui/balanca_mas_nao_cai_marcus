package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.engenheiros_obras;

public class daoEngenheirosObras {
    private DataSource dataSource;

    public daoEngenheirosObras(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<engenheiros_obras> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM engenheiros_obras";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<engenheiros_obras> lista = new ArrayList<>();
            while (rs.next()) {
                engenheiros_obras engObra = new engenheiros_obras();
                engObra.setIdEngenheiro(rs.getInt("idEngenheiro"));
                engObra.setIdObra(rs.getInt("idObra"));
                engObra.setDtInicio(rs.getDate("dtInicio"));
                engObra.setDtFim(rs.getDate("dtFim"));
                engObra.setIdFuncao(rs.getInt("idFuncao"));
                lista.add(engObra);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(engenheiros_obras engObra) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO engenheiros_obras "
                       + "(idEngenheiro, idObra, dtInicio, dtFim, idFuncao) "
                       + "VALUES (?, ?, ?, ?, ?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setInt(1, engObra.getIdEngenheiro());
            ps.setInt(2, engObra.getIdObra());
            ps.setDate(3, engObra.getDtInicio() == null ? null : new java.sql.Date(engObra.getDtInicio().getTime()));
            ps.setDate(4, engObra.getDtFim() == null ? null : new java.sql.Date(engObra.getDtFim().getTime()));
            ps.setInt(5, engObra.getIdFuncao());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(engenheiros_obras engObra) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE engenheiros_obras "
               + "SET dtInicio=?, dtFim=?, idFuncao=? "
               + "WHERE idEngenheiro=? AND idObra=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setDate(1, engObra.getDtInicio() == null ? null : new java.sql.Date(engObra.getDtInicio().getTime()));
            ps.setDate(2, engObra.getDtFim() == null ? null : new java.sql.Date(engObra.getDtFim().getTime()));
            ps.setInt(3, engObra.getIdFuncao());
            ps.setInt(4, engObra.getIdEngenheiro());
            ps.setInt(5, engObra.getIdObra());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idEngenheiro, int idObra) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM engenheiros_obras WHERE (idEngenheiro=? AND idObra=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idEngenheiro);
            ps.setInt(2, idObra);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
