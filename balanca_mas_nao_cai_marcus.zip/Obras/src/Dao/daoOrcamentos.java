package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.orcamentos;

public class daoOrcamentos {
    private DataSource dataSource;

    public daoOrcamentos(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<orcamentos> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM orcamentos";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<orcamentos> lista = new ArrayList<>();
            while (rs.next()) {
                orcamentos orc = new orcamentos();
                orc.setIdOrcamento(rs.getInt("idOrcamento"));
                orc.setDtOrcamento(rs.getDate("dtOrcamento"));
                orc.setDtAprovacao(rs.getDate("dtAprovacao"));
                lista.add(orc);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(orcamentos orc) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO orcamentos "
                       + "(idOrcamento, dtOrcamento, dtAprovacao) "
                       + "VALUES (?, ?, ?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setInt(1, orc.getIdOrcamento());
            ps.setDate(2, orc.getDtOrcamento() == null ? null : new java.sql.Date(orc.getDtOrcamento().getTime()));
            ps.setDate(3, orc.getDtAprovacao() == null ? null : new java.sql.Date(orc.getDtAprovacao().getTime()));

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(orcamentos orc) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE orcamentos "
               + "SET dtOrcamento=?, dtAprovacao=? "
               + "WHERE idOrcamento=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setDate(1, orc.getDtOrcamento() == null ? null : new java.sql.Date(orc.getDtOrcamento().getTime()));
            ps.setDate(2, orc.getDtAprovacao() == null ? null : new java.sql.Date(orc.getDtAprovacao().getTime()));
            ps.setInt(3, orc.getIdOrcamento());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idOrcamento) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM orcamentos WHERE (idOrcamento=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idOrcamento);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
