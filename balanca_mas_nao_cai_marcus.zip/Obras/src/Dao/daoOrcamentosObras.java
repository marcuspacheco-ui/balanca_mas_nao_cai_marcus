package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.orcamentos_obras;

public class daoOrcamentosObras {
    private DataSource dataSource;

    public daoOrcamentosObras(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<orcamentos_obras> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT * FROM orcamentos_obras";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<orcamentos_obras> lista = new ArrayList<>();
            while (rs.next()) {
                orcamentos_obras orcObra = new orcamentos_obras();
                orcObra.setIdOrcamento(rs.getInt("idOrcamento"));
                orcObra.setIdObra(rs.getInt("idObra"));
                orcObra.setDtInicio(rs.getDate("dtInicio"));
                orcObra.setDtFim(rs.getDate("dtFim"));
                orcObra.setVlPrevisto(rs.getDouble("vlPrevisto"));
                orcObra.setVlRealizado(rs.getDouble("vlRealizado"));
                lista.add(orcObra);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(orcamentos_obras orcObra) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO orcamentos_obras "
                       + "(idOrcamento, idObra, dtInicio, dtFim, vlPrevisto, vlRealizado) "
                       + "VALUES (?, ?, ?, ?, ?, ?)";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setInt(1, orcObra.getIdOrcamento());
            ps.setInt(2, orcObra.getIdObra());
            ps.setDate(3, orcObra.getDtInicio() == null ? null : new java.sql.Date(orcObra.getDtInicio().getTime()));
            ps.setDate(4, orcObra.getDtFim() == null ? null : new java.sql.Date(orcObra.getDtFim().getTime()));
            ps.setDouble(5, orcObra.getVlPrevisto());
            ps.setDouble(6, orcObra.getVlRealizado());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(orcamentos_obras orcObra) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE orcamentos_obras "
               + "SET dtInicio=?, dtFim=?, vlPrevisto=?, vlRealizado=? "
               + "WHERE idOrcamento=? AND idObra=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setDate(1, orcObra.getDtInicio() == null ? null : new java.sql.Date(orcObra.getDtInicio().getTime()));
            ps.setDate(2, orcObra.getDtFim() == null ? null : new java.sql.Date(orcObra.getDtFim().getTime()));
            ps.setDouble(3, orcObra.getVlPrevisto());
            ps.setDouble(4, orcObra.getVlRealizado());
            ps.setInt(5, orcObra.getIdOrcamento());
            ps.setInt(6, orcObra.getIdObra());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idOrcamento, int idObra) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM orcamentos_obras WHERE (idOrcamento=? AND idObra=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idOrcamento);
            ps.setInt(2, idObra);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
