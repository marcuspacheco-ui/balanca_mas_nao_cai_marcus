package Dao;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import model.obras;

public class daoObras {
    private DataSource dataSource;

    public daoObras(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public ArrayList<obras> consulta() {
        PreparedStatement ps = null;
        try {
            String SQL = "SELECT obras.*, engenheiros.dsNome FROM obras LEFT JOIN engenheiros ON engenheiros.idEngenheiro = obras.idEngenheiro";
            ps = dataSource.getConnection().prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();

            ArrayList<obras> lista = new ArrayList<>();
            while (rs.next()) {
                obras obra = new obras();
                obra.setIdObra(rs.getInt("idObra"));
                obra.setDescricao(rs.getString("Descricao"));
                obra.setDtInicio(rs.getDate("dtInicio"));
                obra.setDtFim(rs.getDate("dtFim"));
                obra.setIdEngenheiro(rs.getInt("idEngenheiro"));
                obra.setNrCrea(rs.getString("nrCrea"));
                obra.setDtDdmissaoEngenheiro(rs.getDate("dtDdmissaoEngenheiro"));
                obra.setDsNome(rs.getString("dsNome"));
                lista.add(obra);
            }
            ps.close();
            return lista;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO ao consultar: " + ex.getMessage());
            return null;
        }
    }

    public void incluir(obras obra) {
        PreparedStatement ps = null;
        try {
            String SQL = "INSERT INTO obras "
                       + "(idObra, Descricao, dtInicio, dtFim, idEngenheiro, nrCrea, dtDdmissaoEngenheiro) "
                       + "SELECT COALESCE(MAX(idObra), 0) + 1, ?, ?, ?, ?, ?, ? FROM obras";

            ps = dataSource.getConnection().prepareStatement(SQL);
            ps.setString(1, obra.getDescricao());
            ps.setDate(2, obra.getDtInicio() == null ? null : new java.sql.Date(obra.getDtInicio().getTime()));
            ps.setDate(3, obra.getDtFim() == null ? null : new java.sql.Date(obra.getDtFim().getTime()));
            ps.setInt(4, obra.getIdEngenheiro());
            ps.setString(5, obra.getNrCrea());
            ps.setDate(6, obra.getDtDdmissaoEngenheiro() == null ? null : new java.sql.Date(obra.getDtDdmissaoEngenheiro().getTime()));

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void alterar(obras obra) {
        PreparedStatement ps = null;

        try {
            String SQL = "UPDATE obras "
               + "SET Descricao=?, dtInicio=?, dtFim=?, idEngenheiro=?, nrCrea=?, dtDdmissaoEngenheiro=? "
               + "WHERE idObra=?";

            ps = dataSource.getConnection().prepareStatement(SQL);

            ps.setString(1, obra.getDescricao());
            ps.setDate(2, obra.getDtInicio() == null ? null : new java.sql.Date(obra.getDtInicio().getTime()));
            ps.setDate(3, obra.getDtFim() == null ? null : new java.sql.Date(obra.getDtFim().getTime()));
            ps.setInt(4, obra.getIdEngenheiro());
            ps.setString(5, obra.getNrCrea());
            ps.setDate(6, obra.getDtDdmissaoEngenheiro() == null ? null : new java.sql.Date(obra.getDtDdmissaoEngenheiro().getTime()));
            ps.setInt(7, obra.getIdObra());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Alterado com sucesso!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar: " + ex.getMessage());
        } finally {
            dataSource.closeDataSource();
        }
    }

    public void excluir(int idObra) {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = null;

        try {
            String SQL = "DELETE FROM obras WHERE (idObra=?)";

            ps = con.prepareStatement(SQL);
            ps.setInt(1, idObra);

            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir!\n" + ex);
        } finally {
            dataSource.closeDataSource();
        }
    }
}
