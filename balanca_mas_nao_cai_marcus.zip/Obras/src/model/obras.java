package model;

import java.util.Date;

public class obras {
    private int idObra;
    private String Descricao;
    private Date dtInicio;
    private Date dtFim;
    private int idEngenheiro;
    private String nrCrea;
    private Date dtDdmissaoEngenheiro;
    private String dsNome;

    /**
     * @return the idObra
     */
    public int getIdObra() {
        return idObra;
    }

    /**
     * @param idObra the idObra to set
     */
    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    /**
     * @return the Descricao
     */
    public String getDescricao() {
        return Descricao;
    }

    /**
     * @param Descricao the Descricao to set
     */
    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }

    /**
     * @return the dtInicio
     */
    public Date getDtInicio() {
        return dtInicio;
    }

    /**
     * @param dtInicio the dtInicio to set
     */
    public void setDtInicio(Date dtInicio) {
        this.dtInicio = dtInicio;
    }

    /**
     * @return the dtFim
     */
    public Date getDtFim() {
        return dtFim;
    }

    /**
     * @param dtFim the dtFim to set
     */
    public void setDtFim(Date dtFim) {
        this.dtFim = dtFim;
    }

    /**
     * @return the idEngenheiro
     */
    public int getIdEngenheiro() {
        return idEngenheiro;
    }

    /**
     * @param idEngenheiro the idEngenheiro to set
     */
    public void setIdEngenheiro(int idEngenheiro) {
        this.idEngenheiro = idEngenheiro;
    }

    /**
     * @return the nrCrea
     */
    public String getNrCrea() {
        return nrCrea;
    }

    /**
     * @param nrCrea the nrCrea to set
     */
    public void setNrCrea(String nrCrea) {
        this.nrCrea = nrCrea;
    }

    /**
     * @return the dtDdmissaoEngenheiro
     */
    public Date getDtDdmissaoEngenheiro() {
        return dtDdmissaoEngenheiro;
    }

    /**
     * @param dtDdmissaoEngenheiro the dtDdmissaoEngenheiro to set
     */
    public void setDtDdmissaoEngenheiro(Date dtDdmissaoEngenheiro) {
        this.dtDdmissaoEngenheiro = dtDdmissaoEngenheiro;
    }

    /**
     * @return the dsNome
     */
    public String getDsNome() {
        return dsNome;
    }

    /**
     * @param dsNome the dsNome to set
     */
    public void setDsNome(String dsNome) {
        this.dsNome = dsNome;
    }
}
