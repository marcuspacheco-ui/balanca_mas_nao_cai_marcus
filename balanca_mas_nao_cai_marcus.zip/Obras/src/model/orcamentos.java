package model;

import java.util.Date;

public class orcamentos {
    private int idOrcamento;
    private Date dtOrcamento;
    private Date dtAprovacao;

    /**
     * @return the idOrcamento
     */
    public int getIdOrcamento() {
        return idOrcamento;
    }

    /**
     * @param idOrcamento the idOrcamento to set
     */
    public void setIdOrcamento(int idOrcamento) {
        this.idOrcamento = idOrcamento;
    }

    /**
     * @return the dtOrcamento
     */
    public Date getDtOrcamento() {
        return dtOrcamento;
    }

    /**
     * @param dtOrcamento the dtOrcamento to set
     */
    public void setDtOrcamento(Date dtOrcamento) {
        this.dtOrcamento = dtOrcamento;
    }

    /**
     * @return the dtAprovacao
     */
    public Date getDtAprovacao() {
        return dtAprovacao;
    }

    /**
     * @param dtAprovacao the dtAprovacao to set
     */
    public void setDtAprovacao(Date dtAprovacao) {
        this.dtAprovacao = dtAprovacao;
    }
}
