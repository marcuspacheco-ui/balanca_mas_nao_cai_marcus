package model;

public class fases {
    private int idFase;
    private String dsFase;

    /**
     * @return the idFase
     */
    public int getIdFase() {
        return idFase;
    }

    /**
     * @param idFase the idFase to set
     */
    public void setIdFase(int idFase) {
        this.idFase = idFase;
    }

    /**
     * @return the dsFase
     */
    public String getDsFase() {
        return dsFase;
    }

    /**
     * @param dsFase the dsFase to set
     */
    public void setDsFase(String dsFase) {
        this.dsFase = dsFase;
    }
}
