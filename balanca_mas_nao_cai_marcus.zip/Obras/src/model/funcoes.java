package model;

public class funcoes {
    private int idFuncao;
    private String dsFuncao;

    /**
     * @return the idFuncao
     */
    public int getIdFuncao() {
        return idFuncao;
    }

    /**
     * @param idFuncao the idFuncao to set
     */
    public void setIdFuncao(int idFuncao) {
        this.idFuncao = idFuncao;
    }

    /**
     * @return the dsFuncao
     */
    public String getDsFuncao() {
        return dsFuncao;
    }

    /**
     * @param dsFuncao the dsFuncao to set
     */
    public void setDsFuncao(String dsFuncao) {
        this.dsFuncao = dsFuncao;
    }
}
